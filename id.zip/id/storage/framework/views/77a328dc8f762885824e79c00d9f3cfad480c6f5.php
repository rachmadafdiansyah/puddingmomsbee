<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mb-5">
        </div>
        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card">
              <img src="<?php echo e(url('uploads')); ?>/<?php echo e($barang->gambar); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title"><?php echo e($barang->nama_barang); ?></h5>
                <p class="card-text">
                    <strong>Harga :</strong> Rp. <?php echo e(number_format($barang->harga)); ?> <br>
                    <strong>Stok :</strong> <?php echo e($barang->stok); ?> <br>
                    <hr>
                    <strong>Keterangan :</strong> <br>
                    <?php echo e($barang->keterangan); ?> 
                </p>
                <a href="<?php echo e(url('pesan')); ?>/<?php echo e($barang->id); ?>" class="btn btn-primary"><i class="fa fa-shopping-cart"></i> Pesan</a>
              </div>
            </div> 
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <footer class="footer mt-auto py-3 bg-primary">
            <div class="container">
                <div class="row align-items-start">
                    <div class="col">
                        <span><strong>Pudding Mom's Bee</strong></span>
                        <hr>
                        <justify>
                            <p align="justify">Pudding Mom's Bee adalah salah satu toko online yang berjualan dessert sejak tahun 2020. Berlokasi di Jakarta Timur, Pudding Mom's Bee merupakan spesialis dessert bertema unik.</p>
                        </justify>
                    </div>
                    <div class="col">
                    </div>
                    <div class="col">
                        <span>
                            <strong>Find Us!</strong>
                        </span>
                        <hr>
                        <p class="lead">
                            </p>
                            <a href="https://shopee.co.id/irasusanti24"><img src="<?php echo e(url('images/shopee.png')); ?>" width="30em" alt=""></a>
                            &nbsp;&nbsp;&nbsp;
                            <a href="https://www.tokopedia.com/pudingmomsbee"><img src="<?php echo e(url('images/tokped.png')); ?>" width="30em" alt=""></a>
                            &nbsp;&nbsp;&nbsp;
                            <a href="https://www.instagram.com/pudingmomsbee/"><img src="<?php echo e(url('images/instagram.png')); ?>" width="30em" alt=""></a>
                            &nbsp;&nbsp;&nbsp;
                            <a href=" https://wa.me/6282113565600"><img src="<?php echo e(url('images/whatsapp.png')); ?>" width="30em" alt=""></a>
                            &nbsp;&nbsp;&nbsp;
                            <a href="https://goo.gl/maps/LFV8MA12koxdFPy69"><img src="<?php echo e(url('images/maps.png')); ?>" width="30em" alt=""></a>
                                            </div>
                </div>
                </div>
            </div>
        </div>
        
    </div>
</div>
<center>
                
                    <a href="<?php echo e(url('home')); ?>" style="text-decoration: none;">
                        © Pudding Mom's Bee
                    </a>
                </center>
            </div>
        </footer>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puddingmomsbees\resources\views/home.blade.php ENDPATH**/ ?>