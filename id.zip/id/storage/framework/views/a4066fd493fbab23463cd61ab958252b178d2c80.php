
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <!-- Tombol Kembali-->
        <div class="col-md-12">
            <a href="<?php echo e(url('pesanan')); ?>" class="btn btn-outline-secondary"><i class="fa fa-arrow-left"></i> Kembali</a>
        </div>
        <!-- Tombol Kembali-->
        <!-- Breadcrumb -->
        <div class="col-md-12 mt-2">
            <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('pesanan')); ?>">Daftar Pesanan</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Detail Pemesanan</li>
                </ol>
            </nav>
        </div>
        <!-- Breadcrumb -->
        <br>
        <br>
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h1 class="mt-2" style=font-size:50px><i class="fas fa-file-invoice"></i> Detail Pesanan</h1>
                    <hr>
                </div>
                <div class="card mt-2">
                    <div class="card-body">
                        <h3><i class="fa fa-shopping-cart"></i> Produk Dipesan</h3>
                        <p align="right">Tanggal Pesan : <?php echo e($pesanan->tanggal); ?></p>
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Gambar</th>
                                    <th>Nama Pemesan</th>
                                    <th>Nama Barang</th>
                                    <th>id Pesanan</th>
                                    <th>Status</th>
                                    <th>Jumlah</th>
                                    <th>Harga</th>
                                    <th>Total Harga</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $pesanan_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td>
                                        <img src="<?php echo e(url('uploads')); ?>/<?php echo e($pesanan_detail->barang->gambar); ?>" width="100" alt="...">
                                    </td>
                                    <td><?php echo e($pesanan->user->name); ?></td>
                                    <td><?php echo e($pesanan_detail->barang->nama_barang); ?></td>
                                    <td><?php echo e($pesanan->id); ?></td>
                                    <td>
                                        <?php if($pesanan->status == 1): ?>
                                        Menunggu Pembayaran
                                        <?php elseif($pesanan->status == 2): ?>
                                        Pesanan Sedang dikemas
                                        <?php elseif($pesanan->status == 3): ?>
                                        Pesanan Sedang dikirim
                                        <?php else: ?>
                                        Transaksi Selesai
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($pesanan_detail->jumlah); ?></td>
                                    <td>Rp. <?php echo e(number_format($pesanan_detail->barang->harga)); ?></td>
                                    <td>Rp. <?php echo e(number_format($pesanan_detail->jumlah_harga)); ?></td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td colspan="5" align="right"><strong>Kode Unik :</strong></td>
                                    <td align="right"><strong>Rp. <?php echo e(number_format($pesanan->kode)); ?></strong></td>

                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td colspan="5" align="right"><strong>Total Harga :</strong></td>
                                    <td align="right"><strong>Rp. <?php echo e(number_format($pesanan->kode+$pesanan->jumlah_harga)); ?></strong></td>

                                </tr>

                            </tbody>
                        </table>
                        <br>
                        <p>No HP : <?php echo e($pesanan->user->nohp); ?> <br>
                            <strong>Alamat Pengiriman :</strong> <br> <?php echo e($pesanan->user->alamat); ?>

                        </p>
                        <br>
                        <br>
                        <br>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/puddingm/public_html/id/resources/views/admin/detail.blade.php ENDPATH**/ ?>