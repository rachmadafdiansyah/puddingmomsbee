<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Tombol Kembali-->
    <div class="col-md-12">
        <a href="<?php echo e(url('admin')); ?>" class="btn btn-outline-secondary"><i class="fa fa-arrow-left"></i> Kembali</a>
    </div>
    <!-- Tombol Kembali-->
    <!-- Breadcrumb -->
    <div class="col-md-12 mt-2">
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Daftar Pesanan</li>
            </ol>
        </nav>
    </div>
    <!-- Breadcrumb -->
    <br>
    <br>
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <h3><i class="fa fa-history"></i> Daftar Pesanan</h3>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>id Pesanan</th>
                            <th>Status</th>
                            <th>Jumlah Harga</th>
                            <th>Aksi</th>
                            <th>#</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $pesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($pesanan->tanggal); ?></td>
                            <td><?php echo e($pesanan->id); ?></td>
                            <td>
                                <?php if($pesanan->status == 1): ?>
                                Menunggu Pembayaran
                                <?php elseif($pesanan->status == 2): ?>
                                Pesanan Sedang dikemas
                                <?php elseif($pesanan->status == 3): ?>
                                Pesanan Sedang dikirim
                                <?php else: ?>
                                Transaksi Selesai
                                <?php endif; ?>
                            </td>
                            <td>Rp. <?php echo e(number_format($pesanan->jumlah_harga+$pesanan->kode)); ?></td>
                            <td>
                                <a href="<?php echo e(url('pesanan')); ?>/<?php echo e($pesanan->id); ?>" class="btn btn-outline-secondary"><i class="fa fa-info"></i> Detail</a>
                            </td>
                            <td>
                                <a href="<?php echo e(url('editpesanan')); ?>/<?php echo e($pesanan->id); ?>" class="btn btn-outline-danger"><i class="fa fa-info"></i> Edit Status</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puddingmomsbee\resources\views/admin/pesanan.blade.php ENDPATH**/ ?>