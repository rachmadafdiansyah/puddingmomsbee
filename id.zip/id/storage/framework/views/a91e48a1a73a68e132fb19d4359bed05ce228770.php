<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-12 mb-3">
        <img src="<?php echo e(url('images/logoP.png')); ?>" class="rounded mx-auto d-block" width="300" alt="">
    </div>
    <hr class="featurette-divider">
    <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 mb-4">
        <div class="card">
            <a href="<?php echo e(url('edit')); ?>/<?php echo e($barang->id); ?>"><img class="card-img-top" src="<?php echo e(url('uploads')); ?>/<?php echo e($barang->gambar); ?>" alt="Card image cap"></a>
            <div class="card-body">
                <center>
                    <a href="<?php echo e(url('edit')); ?>/<?php echo e($barang->id); ?>" style="text-decoration: none;">
                        <h3 class="card-title" style="color:black;"><?php echo e($barang->nama_barang); ?></h3>
                    </a>
                </center>
                <p class="card-text">
                    <strong>Harga :</strong> Rp. <?php echo e(number_format($barang->harga)); ?> <br>
                    <strong>Stok :</strong> <?php echo e($barang->stok); ?> <br>
                    <strong>Keterangan :</strong> <br>
                    <?php echo e($barang->keterangan); ?>

                    <hr>

                </p>
                <a href="<?php echo e(url('edit')); ?>/<?php echo e($barang->id); ?>" class="btn btn-outline-secondary"> <i class="fa fa-pencil-alt"></i> Edit </a>
                <br>
                </br>
                <form action="<?php echo e(url('edit')); ?>/<?php echo e($barang->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="btn btn-outline-danger" onclick="return confirm('Anda yakin akan menghapus data ?');"><i class="fa fa-trash"></i> Delete</button>
                </form>

            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puddingmomsbee\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>