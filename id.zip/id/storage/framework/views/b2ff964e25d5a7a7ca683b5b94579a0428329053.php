<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Tombol Kembali-->
    <div class="col-md-12">
        <a href="<?php echo e(url('admin')); ?>" class="btn btn-outline-secondary"><i class="fa fa-arrow-left"></i> Kembali</a>
    </div>
    <!-- Tombol Kembali-->
    <!-- Breadcrumb -->
    <div class="col-md-12 mt-2">
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Edit Produk</li>
            </ol>
        </nav>
    </div>
    <!-- Breadcrumb -->
    <br>
    <br>
    <div class="col-md-12 mt-1">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <img src="<?php echo e(url('uploads')); ?>/<?php echo e($barang->gambar); ?>" class="rounded mx-auto d-block" width="50%" alt="">
                    </div>
                    <div class="col-md-6 mt-5">
                        <h2><?php echo e($barang->nama_barang); ?></h2>
                        <table class="table">
                            <tbody>
                                <tr>
                                    <td>Harga</td>
                                    <td>:</td>
                                    <td>Rp. <?php echo e(number_format($barang->harga)); ?></td>
                                </tr>
                                <tr>
                                    <td>Stok</td>
                                    <td>:</td>
                                    <td><?php echo e(number_format($barang->stok)); ?></td>
                                </tr>
                                <tr>
                                    <td>Keterangan</td>
                                    <td>:</td>
                                    <td><?php echo e($barang->keterangan); ?></td>
                                </tr>

                                <tr>
                                    <td>Gambar</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($barang->gambar); ?>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <h2><i class="fa fa-pencil-alt"></i> Edit Produk</h2>
                        <form method="POST" action="<?php echo e(url('edit')); ?>/<?php echo e($barang->id); ?>">
                            <?php echo csrf_field(); ?>
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <td>Nama Barang</td>
                                        <td>:</td>
                                        <td>
                                            <div class="col-md-6">
                                                <input id="nama_barang" type="text" class="form-control <?php if ($errors->has('nama_barang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_barang'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nama_barang" value="<?php echo e($barang->nama_barang); ?>" required autocomplete="nama_barang" autofocus>

                                                <?php if ($errors->has('nama_barang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_barang'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Harga</td>
                                        <td>:</td>
                                        <td>
                                            <div class="col-md-6">
                                                <input id="harga" type="harga" class="form-control <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="harga" value="<?php echo e($barang->harga); ?>" required autocomplete="harga">

                                                <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Stok</td>
                                        <td>:</td>
                                        <td>
                                            <div class="col-md-6">
                                                <input id="stok" type="text" class="form-control <?php if ($errors->has('stok')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('stok'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="stok" value="<?php echo e($barang->stok); ?>" required autocomplete="stok" autofocus>

                                                <?php if ($errors->has('stok')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('stok'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Keterangan</td>
                                        <td>:</td>
                                        <td>
                                            <div class="col-md-6">
                                                <textarea name="keterangan" class="form-control <?php if ($errors->has('keterangan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('keterangan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required=""><?php echo e($barang->keterangan); ?></textarea>

                                                <?php if ($errors->has('keterangan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('keterangan'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>Gambar</td>
                                        <td>:</td>
                                        <td>
                                            <div class="col-md-6">
                                                <textarea name="gambar" class="form-control <?php if ($errors->has('gambar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gambar'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required=""><?php echo e($barang->gambar); ?></textarea>

                                                <?php if ($errors->has('gambar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gambar'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-2">
                                    <button type="submit" class="btn btn-outline-secondary">
                                        Save
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puddingmomsbe\resources\views/admin/edit.blade.php ENDPATH**/ ?>