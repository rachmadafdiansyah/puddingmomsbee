<?php $__env->startSection('content'); ?>
            <div class="container">
        <main class="py-1">
            <div class="content">
                <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel" data-interval="100">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <a href="<?php echo e(url('home')); ?>"><img src="<?php echo e(url('images/1.jpg')); ?>" class="d-block w-100" alt="..."></a>
                            <div class="carousel-caption d-none d-md-block">
                                <a href="<?php echo e(url('home')); ?>" class="btn btn-light stretched-link"> Shop Now </a>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <a href="<?php echo e(url('home')); ?>"><img src="<?php echo e(url('images/2.jpg')); ?>" class="d-block w-100" alt="..."></a>
                            <div class="carousel-caption d-none d-md-block">
                                <a href="<?php echo e(url('home')); ?>" class="btn btn-light stretched-link"> Shop Now </a>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <a href="<?php echo e(url('home')); ?>"><img src="<?php echo e(url('images/3.jpg')); ?>" class="d-block w-100" alt="..."></a>
                            <div class="carousel-caption d-none d-md-block">
                                <a href="<?php echo e(url('home')); ?>" class="btn btn-light stretched-link"> Shop Now </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                <br>
            </br>
        </main>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puddingmomsbee\resources\views/welcome.blade.php ENDPATH**/ ?>