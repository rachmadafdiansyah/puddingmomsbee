

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Tombol Kembali-->
    <div class="col-md-12">
        <a href="<?php echo e(url('admin')); ?>" class="btn btn-outline-secondary"><i class="fa fa-arrow-left"></i> Kembali</a>
    </div>
    <!-- Tombol Kembali-->
    <!-- Breadcrumb -->
    <div class="col-md-12 mt-2">
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Tambah Produk</li>
            </ol>
        </nav>
    </div>
    <!-- Breadcrumb -->
    <br>
    <br>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h1 class='mt-2'>Tambah Produk</h1>
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('admin.add')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="nama_barang" class="col-md-4 col-form-label text-md-right">Nama Barang</label>

                            <div class="col-md-6">
                                <input id="nama_barang" type="text" class="form-control <?php if ($errors->has('nama_barang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_barang'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nama_barang" value="<?php echo e(old('nama_barang')); ?>" required autocomplete="nama_barang" autofocus>

                                <?php if ($errors->has('nama_barang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_barang'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="gambar" class="col-md-4 col-form-label text-md-right">Nama File Gambar</label>

                            <div class="col-md-6">
                                <input id="gambar" type="gambar" class="form-control <?php if ($errors->has('gambar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gambar'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="gambar" value="<?php echo e(old('gambar')); ?>" required autocomplete="gambar">

                                <?php if ($errors->has('gambar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gambar'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="harga" class="col-md-4 col-form-label text-md-right">Harga</label>

                            <div class="col-md-6">
                                <input id="harga" type="text" class="form-control <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="harga" value="<?php echo e(old('harga')); ?>" required autocomplete="harga" autofocus>

                                <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="stok" class="col-md-4 col-form-label text-md-right">Stok</label>

                            <div class="col-md-6">
                                <input id="stok" type="stok" class="form-control <?php if ($errors->has('gambar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gambar'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="stok" value="<?php echo e(old('stok')); ?>" required autocomplete="stok">

                                <?php if ($errors->has('stok')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('stok'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="keterangan" class="col-md-4 col-form-label text-md-right">Keterangan</label>

                            <div class="col-md-6">
                                <input id="keterangan" type="keterangan" class="form-control <?php if ($errors->has('keterangan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('keterangan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="keterangan" value="<?php echo e(old('keterangan')); ?>" required autocomplete="keterangan">

                                <?php if ($errors->has('keterangan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('keterangan'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Tambah Produk
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
        <br>
        </br>
        <hr class="featurette-divider mb-4 mt-4">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Gambar</th>
                                <th scope="col">Nama Gambar</th>
                                <th scope="col">Nama File</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td><img src="<?php echo e(url ('uploads/a1.png')); ?>" width="100" alt="..."></td>
                                <td>Front Astrofish</td>
                                <td>a1.png</td>
                            </tr>
                            <tr>
                                <th scope="row">2</th>
                                <td><img src="<?php echo e(url ('uploads/z1.png')); ?>" width="100" alt="..."></td>
                                <td>Front Zomtronaut</td>
                                <td>z1.png</td>
                            </tr>
                            <tr>
                                <th scope="row">3</th>
                                <td><img src="<?php echo e(url ('uploads/w.png')); ?>" width="100" alt="..."></td>
                                <td>Front Wormhole</td>
                                <td>w.png</td>
                            </tr>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/puddingm/public_html/ids/resources/views/admin/add.blade.php ENDPATH**/ ?>