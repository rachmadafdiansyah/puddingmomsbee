<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Pudding Mom's Bee</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!--Custom Styles -->
    <style>
        html,
        body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            height: 100vh;
            margin: 0;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
    <!--Custom Styles -->

</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-black shadow-sm">
            <div class="container">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>">Katalog</a>
                    </li>
                </ul>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->

                        <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                        <?php endif; ?>
                        <?php else: ?>
                        <li class="nav-item">
                            <?php
                            $pesanan_utama = \App\Pesanan::where('user_id', Auth::user()->id)->where('status', 0)->first();
                            if (!empty($pesanan_utama)) {
                                $notif = \App\PesananDetail::where('pesanan_id', $pesanan_utama->id)->count();
                            }
                            ?>
                            <a class="nav-link" href="<?php echo e(url('check-out')); ?>">
                                <i class="fa fa-shopping-cart"></i>
                                <?php if(!empty($notif)): ?>
                                <span class="badge badge-danger"><?php echo e($notif); ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(url('profile')); ?>">
                                    Profile
                                </a>

                                <a class="dropdown-item" href="<?php echo e(url('history')); ?>">
                                    Riwayat Pemesanan
                                </a>

                                <a class="dropdown-item" href="<?php echo e(url('faqs')); ?>">
                                    FAQs
                                </a>

                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-1">
            <div class="content">
                <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel" data-interval="100">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <a href="<?php echo e(url('home')); ?>"><img src="<?php echo e(url('images/1.jpg')); ?>" class="d-block w-100" alt="..."></a>
                            <div class="carousel-caption d-none d-md-block">
                                <a href="<?php echo e(url('home')); ?>" class="btn btn-light stretched-link"> Shop Now </a>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <a href="<?php echo e(url('home')); ?>"><img src="<?php echo e(url('images/2.jpg')); ?>" class="d-block w-100" alt="..."></a>
                            <div class="carousel-caption d-none d-md-block">
                                <a href="<?php echo e(url('home')); ?>" class="btn btn-light stretched-link"> Shop Now </a>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <a href="<?php echo e(url('home')); ?>"><img src="<?php echo e(url('images/3.jpg')); ?>" class="d-block w-100" alt="..."></a>
                            <div class="carousel-caption d-none d-md-block">
                                <a href="<?php echo e(url('home')); ?>" class="btn btn-light stretched-link"> Shop Now </a>
                            </div>
                        </div>
                    </div>
                </div>
                  <footer class="footer mt-auto py-3 bg-primary">
            <div class="container">
                <div class="row align-items-start">
                    <div class="col">
                        <span><strong>Pudding Mom's Bee</strong></span>
                        <hr>
                        <justify>
                            <p align="justify">Pudding Mom's Bee adalah salah satu toko online yang berjualan dessert sejak tahun 2020. Berlokasi di Jakarta Timur, Pudding Mom's Bee merupakan spesialis dessert bertema unik.</p>
                        </justify>
                    </div>
                    <div class="col">
                    </div>
                    <div class="col">
                        <span>
                            <strong>Find Us!</strong>
                        </span>
                        <hr>
                        <p class="lead">
                            </p>
                            <a href="https://shopee.co.id/irasusanti24"><img src="<?php echo e(url('images/shopee.png')); ?>" width="30em" alt=""></a>
                            &nbsp;&nbsp;&nbsp;
                            <a href="https://www.tokopedia.com/pudingmomsbee"><img src="<?php echo e(url('images/tokped.png')); ?>" width="30em" alt=""></a>
                            &nbsp;&nbsp;&nbsp;
                            <a href="https://www.instagram.com/pudingmomsbee/"><img src="<?php echo e(url('images/instagram.png')); ?>" width="30em" alt=""></a>
                            &nbsp;&nbsp;&nbsp;
                            <a href=" https://wa.me/6282113565600"><img src="<?php echo e(url('images/whatsapp.png')); ?>" width="30em" alt=""></a>
                            &nbsp;&nbsp;&nbsp;
                            <a href="https://goo.gl/maps/LFV8MA12koxdFPy69"><img src="<?php echo e(url('images/maps.png')); ?>" width="30em" alt=""></a>
                                            </div>
                </div>
                </div>
            </div>
        </div>
        
    </div>
</div>
<center>
                
                    <a href="<?php echo e(url('home')); ?>" style="text-decoration: none;">
                        © Pudding Mom's Bee
                    </a>
                </center>
            </div>
        </footer>
                        </div>
                </div>
            </div>
        </main>
    </div>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\puddingmomsbees\resources\views/welcome.blade.php ENDPATH**/ ?>